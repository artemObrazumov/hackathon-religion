package com.borsch_team.hackathonReligion.ui.churches

data class ChurchMarkerData(val churchID: String)