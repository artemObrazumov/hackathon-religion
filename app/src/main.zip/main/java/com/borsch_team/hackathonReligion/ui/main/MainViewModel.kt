package com.borsch_team.hackathonReligion.ui.main

import androidx.lifecycle.ViewModel

class MainViewModel: ViewModel() {

}