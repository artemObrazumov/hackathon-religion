package com.borsch_team.hackathonReligion.data.models

data class FilmModel(
    val name: String = "",
    val duration: String = "",
    val src_video: String = "",
    val src_preview_video: String = "",
)