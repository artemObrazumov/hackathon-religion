package com.borsch_team.hackathonReligion.ui.churches

import com.yandex.mapkit.geometry.Point


class ChurchesPositions {
    companion object {
        val oldChurches = arrayListOf(
            ChurchData(
                Point(55.386894, 43.813457),
                "0"
            )
        )
    }
}