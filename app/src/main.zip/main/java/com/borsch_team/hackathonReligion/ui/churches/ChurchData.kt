package com.borsch_team.hackathonReligion.ui.churches

import com.yandex.mapkit.geometry.Point


data class ChurchData (
    var x: Double = 0.0,
    var y: Double = 0.0,
    var id: String = ""
)